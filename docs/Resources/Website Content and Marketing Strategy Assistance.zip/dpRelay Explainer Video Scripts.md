# dpRelay Explainer Video Scripts

This document provides scripts for short explainer videos, designed to clearly communicate dpRelay's value proposition and unique features to different target audiences. Each script aims to be concise, engaging, and benefit-oriented.

## Video 1: General Overview (Target: Broad Audience - Developers & Business Owners)

**Video Title:** dpRelay: The Future of OTP & Bulk SMS in Bangladesh
**Length:** 60-90 seconds

---

**Scene 1: (0-5 seconds) - Hook & Problem Introduction**

*   **Visual:** Fast-paced montage of frustrated users waiting for OTPs, failed SMS notifications, generic sender IDs. Quick cuts.
*   **Audio (Voiceover - energetic, slightly concerned tone):** "Are your customers waiting too long for OTPs? Are your marketing SMS campaigns getting lost in the void? In today's digital world, reliable communication is non-negotiable. But traditional SMS gateways often fall short."

**Scene 2: (5-15 seconds) - Introducing dpRelay & The Core Solution**

*   **Visual:** Transition to a sleek animation of a smartphone connected to a server, with data flowing smoothly. dpRelay logo appears prominently.
*   **Audio (Voiceover - confident, clear tone):** "Introducing dpRelay – the revolutionary OTP and bulk SMS platform built for Bangladesh. We've solved the reliability crisis with a unique, hardware-authenticated delivery system."

**Scene 3: (15-30 seconds) - How It Works (Simplified)**

*   **Visual:** Simple, clean animation showing a dedicated Android device physically sending an SMS, bypassing a chaotic cloud of generic servers. Highlight "Your Device, Your Control."
*   **Audio (Voiceover):** "Unlike shared gateways, dpRelay uses a dedicated Android device that *you* control. This means every SMS, every OTP, is sent directly from a trusted source. No more random numbers, no more unpredictable delivery."

**Scene 4: (30-45 seconds) - Key Benefits**

*   **Visual:** Split screen or quick transitions showing:
    *   **Left:** A clock showing 2-5 seconds, a checkmark. **Right:** A developer happily coding.
    *   **Left:** A consistent phone number icon. **Right:** A customer smiling, receiving an SMS.
    *   **Left:** Two distinct credit pools (OTP & Bulk). **Right:** A business owner reviewing analytics.
*   **Audio (Voiceover):** "Experience unmatched reliability with OTPs delivered in seconds. Build trust with consistent sender IDs. And manage both transactional OTPs and high-volume bulk campaigns with separate, optimized credit pools. It's developer-friendly, with a clean API and real-time webhooks."

**Scene 5: (45-55 seconds) - Local Advantage & Impact**

*   **Visual:** Map of Bangladesh highlighting connectivity. bKash logo. Diverse businesses thriving.
*   **Audio (Voiceover):** "Built specifically for Bangladesh, dpRelay supports +880 numbers, integrates with bKash, and offers local support. We empower e-commerce, fintech, and mobile app developers to connect reliably with their customers."

**Scene 6: (55-60 seconds) - Call to Action**

*   **Visual:** dpRelay logo, website URL (dprelay.digital-papyrus.xyz), and "Start Free Trial" button.
*   **Audio (Voiceover):** "Ready to revolutionize your SMS communication? Visit dprelay.digital-papyrus.xyz and get started with 50 free OTPs today! dpRelay: Reliable SMS, Powered by You."

---

## Video 2: Developer-Focused (Target: Mobile App Developers, CTOs)

**Video Title:** dpRelay for Developers: Code Reliable OTPs, Fast.
**Length:** 45-60 seconds

---

**Scene 1: (0-5 seconds) - Developer Pain Point**

*   **Visual:** Developer looking frustrated at a screen with error messages or slow loading indicators. Code snippets with comments like "// OTP failed again?"
*   **Audio (Voiceover - empathetic, technical tone):** "Building great apps is hard enough. Don't let unreliable SMS gateways compromise your user experience. Slow OTPs, inconsistent delivery – it's a developer's nightmare."

**Scene 2: (5-15 seconds) - The dpRelay API & Hardware**

*   **Visual:** Clean UI of dpRelay dashboard, showing API keys, code examples (Node.js, Python). Animation of data flowing from a server to a dedicated phone.
*   **Audio (Voiceover):** "dpRelay is built by developers, for developers. Our hardware-authenticated system ensures your OTPs are delivered directly, reliably, and fast – typically within 2-5 seconds. It's a clean, RESTful API designed for seamless integration."

**Scene 3: (15-30 seconds) - Key Developer Features**

*   **Visual:** Highlight features:
    *   **Webhooks:** Animation of a webhook notification triggering a successful event in an app.
    *   **API Playground:** Developer testing code live.
    *   **SDKs:** Logos of Laravel, React, Next.js, Node.js.
    *   **Rate Limiting:** UI showing custom rate limits being set.
*   **Audio (Voiceover):** "Get real-time delivery status with signed webhooks. Test your integration live in our API Playground. We provide ready-to-copy code examples for your favorite frameworks and fine-grained rate limiting to protect your users from abuse. Plus, per-app API keys for multi-client management."

**Scene 4: (30-40 seconds) - Local & Global Ready**

*   **Visual:** +880 number being verified. bKash payment interface.
*   **Audio (Voiceover):** "Optimized for +880 numbers and local payments like bKash, dpRelay is your go-to for Bangladesh. And our architecture is globally ready when you are."

**Scene 5: (40-45 seconds) - Call to Action**

*   **Visual:** dpRelay logo, "View API Docs" button, website URL.
*   **Audio (Voiceover):** "Stop debugging SMS issues. Start building. Explore the dpRelay API documentation and get 50 free OTPs to kickstart your next project. dpRelay: Reliable APIs, Real Results."

---

## Video 3: Business Owner Focused (Target: E-commerce, Fintech, Marketing Managers)

**Video Title:** Secure Your Business: Reliable OTP & Bulk SMS with dpRelay
**Length:** 45-60 seconds

---

**Scene 1: (0-5 seconds) - Business Pain Point**

*   **Visual:** Customer abandoning a cart due to failed OTP. Marketing manager frustrated with low SMS campaign reach. Generic, untrusted SMS messages.
*   **Audio (Voiceover - professional, problem-solving tone):** "Is your business losing customers due to failed verifications? Are your important SMS alerts not reaching their destination? Unreliable communication costs you sales and trust."

**Scene 2: (5-15 seconds) - dpRelay's Business Value**

*   **Visual:** A business owner confidently managing their dashboard. Animation showing a consistent sender ID appearing on a customer's phone. Secure transaction graphic.
*   **Audio (Voiceover):** "dpRelay provides the reliable OTP and bulk SMS solutions your business needs to thrive. Build unwavering customer trust with consistent sender IDs, ensuring every message comes from your brand."

**Scene 3: (15-30 seconds) - Operational Benefits**

*   **Visual:** Highlight features:
    *   **Separate Credit Pools:** UI showing OTP and Bulk SMS credit balances.
    *   **Bulk Campaign Manager:** Business owner scheduling a campaign, seeing real-time delivery.
    *   **Local Payments:** bKash logo, easy top-up process.
*   **Audio (Voiceover):** "Manage your operations efficiently with separate credit pools for critical OTPs and high-volume marketing campaigns. Our intuitive dashboard and bulk campaign manager make it easy to reach your audience. And with local payment options like bKash, managing your account is hassle-free."

**Scene 4: (30-40 seconds) - Local Focus & Support**

*   **Visual:** Happy customers receiving notifications. Local support team icon.
*   **Audio (Voiceover):** "Built for the Bangladesh market, dpRelay understands your needs. We offer affordable, transparent pricing and dedicated local support to ensure your business stays connected."

**Scene 5: (40-45 seconds) - Call to Action**

*   **Visual:** dpRelay logo, "Learn More" button, website URL.
*   **Audio (Voiceover):** "Secure your customer communications and boost your marketing reach. Visit dprelay.digital-papyrus.xyz to learn how dpRelay can transform your business. dpRelay: Your Business, Connected."
